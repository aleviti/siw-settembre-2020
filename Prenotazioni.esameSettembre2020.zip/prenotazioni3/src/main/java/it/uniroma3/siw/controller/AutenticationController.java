package it.uniroma3.siw.controller;


import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.ui.Model;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import it.uniroma3.siw.CredentialsValidator;
import it.uniroma3.siw.UtenteValidator;
import it.uniroma3.siw.model.Credentials;
import it.uniroma3.siw.model.Utente;
import it.uniroma3.siw.service.CredentialsService;


public class AutenticationController {
	 @Autowired
	     UtenteValidator utenteValidator;
	 
		
	 @Autowired
		 CredentialsValidator credentialsValidator;

		@Autowired
		 CredentialsService credentialsService;
		
	    
	    @RequestMapping(value = "/registrati", method = RequestMethod.GET)
	    public String registrazione( Model model) {
	        model.addAttribute("segreteria",new  Utente());
	        model.addAttribute("credentials", new Credentials());
	        return "Registrazione";
	        
}

}