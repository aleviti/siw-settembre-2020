package it.uniroma3.siw.controller;

import java.util.List;
import it.uniroma3.siw.session.*;
import it.uniroma3.siw.model.Camera;
import org.springframework.stereotype.*;
import it.uniroma3.siw.model.Utente;
import it.uniroma3.siw.service.CameraService;


import org.springframework.beans.factory.annotation.Autowired;


import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class CameraController {

	@Autowired
     CameraService cameraService;

    
	@Autowired
	 SessionData sessionData;
   
	@RequestMapping(value = "/addCamera", method = RequestMethod.GET)
    public String toAddCamera(@ModelAttribute Camera camera, Model model) {
		
		Utente utenteLoggato = this.sessionData.getUtenteLoggato();  
		model.addAttribute("utenteLoggato", utenteLoggato);
        model.addAttribute("camera",camera);
       
        return "camera";
    }
	
	@RequestMapping(value= "/addCamera", method = RequestMethod.POST)
	public String addCamera( @ModelAttribute("camera") Camera camera,@ModelAttribute ("tipoletti")String tipoletti, Model model  )  {
		   
		Utente utenteLoggato = this.sessionData.getUtenteLoggato(); 
		model.addAttribute("utenteLoggato", utenteLoggato);

		cameraService.save(camera);
		return "homeAdmin";
	}
	@RequestMapping(value = "/camereList", method = RequestMethod.GET)
    public String listaCamere(@ModelAttribute("camera") Camera camere,@ModelAttribute ("tipoletti")String tipoletti, Model model) {
		Utente utenteLoggato = this.sessionData.getUtenteLoggato(); 
		List<Camera> camere1 = this.cameraService.findAll();
		model.addAttribute("utenteLoggato", utenteLoggato);
		model.addAttribute("camera",camere1);
		
		 return "Listacamere";
	}
}

	
