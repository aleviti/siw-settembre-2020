package it.uniroma3.siw.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import it.uniroma3.siw.model.Utente;
import it.uniroma3.siw.service.UtenteService;

    @Controller
	public class IndexController {
		
			
	   
		@Autowired
	     UtenteService utenteService;

	    @RequestMapping(value = { "/", "/index"}, method = RequestMethod.GET)
	    public String goToIndex() {
	    	
	    	if(this.utenteService == null) {
	    	
	    	Utente admin= new Utente();
	    	
            
            admin.setNome("nome");
            admin.setCognome("cognome");
            utenteService.save(admin);
	    }
	    
	    
	    
	    return "index";
	    
	}
	    @RequestMapping("/")
	    public void handleRequest() {
	        throw new RuntimeException("test exception");
	    }
}

	
	