package it.uniroma3.siw.controller;


import java.util.List;
import org.springframework.stereotype.*;
import it.uniroma3.siw.session.SessionData;
import it.uniroma3.siw.model.Camera;
import it.uniroma3.siw.model.Prenotazione;
import it.uniroma3.siw.model.Utente;
import it.uniroma3.siw.service.CameraService;
import it.uniroma3.siw.service.PrenotazioneService;


import org.springframework.beans.factory.annotation.Autowired;


import org.springframework.ui.Model;



import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;



import java.sql.Date;
import java.text.ParseException;

@Controller
public class PrenotazioneController {
    @Autowired 
	 PrenotazioneService prenotazioneservice;
    @Autowired 
  	 CameraService cameraservice;
      
    @Autowired
     SessionData sessionData;
   
    
	 
	@RequestMapping(value="/addPrenotazione",method = RequestMethod.GET)
	public String toAddPrenotazione(Model model) {
		Utente utenteLoggato = this.sessionData.getUtenteLoggato();
		model.addAttribute("utenteLoggato", utenteLoggato);
		model.addAttribute("prenotazione",  new Prenotazione() );
		return "prenotazione";
	}

	@RequestMapping(value = "/addPrenotazione", method = RequestMethod.POST)
    public String addPrenotazione(@ModelAttribute("prenotazione") Prenotazione prenotazione,@ModelAttribute ("dataArrivo")String dataArrivo,@ModelAttribute ("dataPartenza")String dataPartenza
                           ,Model model) throws ParseException {
		Date dataArrivo1= (Date) prenotazione.getDataArrivo();
		Date dataPartenza1= (Date) prenotazione.getDataArrivo();
		int numeroOspiti= prenotazione.getNumeroOspiti();
		  List<Camera> camere = this.cameraservice.cercaCamereLibere(dataArrivo1, dataPartenza1, numeroOspiti);  
		Utente utenteLoggato = this.sessionData.getUtenteLoggato();
		
		
		model.addAttribute("listaCamere",  camere );
		model.addAttribute("utenteLoggato ",utenteLoggato);
       
		prenotazioneservice.save(prenotazione);
		
        return "camere.libere";
	}
		
	@RequestMapping(value = {"/camereLibere/{Id}"}, method = RequestMethod.GET)
    public String CamereLibere(@ModelAttribute("prenotazione") Prenotazione prenotazione,@PathVariable Long id,@ModelAttribute ("dataArrivo")String dataArrivo,@ModelAttribute ("dataPartenza")String dataPartenza, Model model) {
		Camera camera = CameraService.getCamera(id);
		prenotazione.setCamera(camera);
		prenotazioneservice.save(prenotazione);
		model.addAttribute("prenotazione", prenotazione);
		
		return "confermaPrenotazione";
	} 
		
	 
	}


