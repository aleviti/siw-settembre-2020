package it.uniroma3.siw.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.stereotype.*;
import it.uniroma3.siw.session.SessionData;
import it.uniroma3.siw.model.Credentials;
import it.uniroma3.siw.model.Utente;
import it.uniroma3.siw.service.CredentialsService;
import it.uniroma3.siw.service.UtenteService;

@Controller
public class UtenteController {
	/*@Autowired
    private UtenteService utenteService;*/

	/*@Autowired
    private CredentialsService credentialsService;*/

    
	@Autowired
	 SessionData sessionData;
   
	@RequestMapping(value = "/addUtente", method = RequestMethod.GET)
    public String me( Model model) {
		
		Utente utenteLoggato = this.sessionData.getUtenteLoggato();  
		Credentials credentials = this.sessionData.getLoggedCredentials();
		model.addAttribute("utenteLoggato", utenteLoggato);
        model.addAttribute("credentials", credentials);
       
        return "utente";
    }
	
}
