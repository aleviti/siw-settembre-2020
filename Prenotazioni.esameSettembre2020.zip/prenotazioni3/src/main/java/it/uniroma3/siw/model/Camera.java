package it.uniroma3.siw.model;



import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Camera {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@Column(nullable = false)
	private int numeroposti;

	@Column(nullable = false)
	private int numeroletti;

	
	@Column(nullable = false)
	private String  tipoletti;
	@Column(nullable = false)
	private Float prezzo;
	
	

	

	
	@OneToMany(mappedBy = "camera")
	private List<Prenotazione> prenotazioni;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public int getNumeroPosti() {
		return numeroposti;
	}

	public void setNumeroPosti(int numeroposti) {
		this.numeroposti = numeroposti;
	}

	public int getNumeroLetti() {
		return numeroletti;
	}

	public void setNumeroLetti(int numeroletti) {
		this.numeroletti = numeroletti;
	}
	public String getTipoLetti() {
		return tipoletti;
	}

	public void setTipoLetti(String tipoletti) {
		this.tipoletti = tipoletti;
	}
	
	public Float getPrezzo() {
		return prezzo;
	}

	public void setPrezzo(Float prezzo) {
		this.prezzo = prezzo;
	}
	public List<Prenotazione> getPrenotazioni() {
		return prenotazioni;
	}

	public void setPrenotazioni(List<Prenotazione> prenotazioni) {
		this.prenotazioni = prenotazioni;
	}

	
	
	

	

	

	
	
}


