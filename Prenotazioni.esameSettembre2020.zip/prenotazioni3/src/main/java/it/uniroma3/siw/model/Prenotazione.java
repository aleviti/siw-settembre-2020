package it.uniroma3.siw.model;


	import java.util.Date;

	import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
	import javax.persistence.GenerationType;
	import javax.persistence.Id;
import javax.persistence.ManyToOne;


	

    @Entity
	public class Prenotazione {
		@Id
		@GeneratedValue(strategy = GenerationType.AUTO)
		private Long id;

		@Column(nullable = false)
		private int  numeroospiti;
		
		@Column(nullable= false)
		private Date dataArrivo;

		@Column(nullable=false)
		private Date dataPartenza;
		
		@ManyToOne
		private Camera camera;
		 
	     
		public Date getDataPartenza() {
			return dataPartenza;
		}

		public void setDataPartenza(Date date) {
			this.dataPartenza = date;
		}

		public Date getDataArrivo() {
			return dataArrivo;
		}

		public void setDataArrivo(Date date) {
			this.dataArrivo = date;
		}

		public int getNumeroOspiti() {
			return numeroospiti;
		}

		public void setNumeroOspiti(int numeroospiti) {
			this.numeroospiti = numeroospiti;
		}

		public void setCamera(Camera camera) {
			this.camera= camera;
			
		}

		

		
		

		
		

		

		
}
