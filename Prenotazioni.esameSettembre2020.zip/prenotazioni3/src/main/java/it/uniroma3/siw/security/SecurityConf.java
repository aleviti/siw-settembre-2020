package it.uniroma3.siw.security;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;

import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import javax.sql.DataSource;
import static it.uniroma3.siw.model.Credentials.ADMIN_ROLE;

@Configuration
@EnableWebSecurity
public class SecurityConf extends WebSecurityConfigurerAdapter {

    @Autowired
    DataSource dataSource;


    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {

        auth.jdbcAuthentication().dataSource(dataSource)

               .passwordEncoder(new BCryptPasswordEncoder())
               .usersByUsernameQuery("select username,password,TRUE from Credentials where username = ?")//
               .authoritiesByUsernameQuery("select username,role from Credentials where username = ?")
        ;

       auth.jdbcAuthentication().dataSource(dataSource)
                .usersByUsernameQuery("select username,password,TRUE from Utente where name = ?")
                .authoritiesByUsernameQuery("select username,role from Utente where name = ?");

    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        //http.csrf().disable();//
        http.authorizeRequests() 
        
                .antMatchers(HttpMethod.GET,"/","/index","/login"/*Aggiungere qui pagine a cui si accede senza login*/).permitAll()
                .antMatchers(HttpMethod.POST,"/","/index","/login"/*Aggiungere qui pagine a cui si accede senza login*/).permitAll()
                .antMatchers("/css/**").permitAll()
               
                .antMatchers(HttpMethod.GET,"/homeAdmin").hasAnyAuthority(ADMIN_ROLE)
                .antMatchers(HttpMethod.POST,"/homeAdmin").hasAnyAuthority(ADMIN_ROLE)
                
                .anyRequest().authenticated()
                
                .and()
                .formLogin()
                .defaultSuccessUrl("/homeAdmin")
                .and()
                .logout()
                .logoutUrl("/logout");
               // .logoutSuccessUrl("/Registrazione");
    }

   
}