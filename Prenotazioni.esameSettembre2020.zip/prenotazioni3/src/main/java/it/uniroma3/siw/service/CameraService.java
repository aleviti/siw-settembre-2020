package it.uniroma3.siw.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.uniroma3.siw.model.Camera;
import it.uniroma3.siw.model.Credentials;
import it.uniroma3.siw.model.Prenotazione;
import it.uniroma3.siw.repository.CameraRepository;


@Service
public class CameraService {
	 @Autowired
	    protected static  CameraRepository cameraRepository;

	 
	   
	    @Transactional
	    public Camera  save(Camera camera) {
	         return this.cameraRepository.save(camera);
	    }



		public List<Camera> findAll() {
		return (List<Camera>) cameraRepository.findAll();
		}

      public List<Camera> cercaCamereLibere(Date dataArrivo, Date dataPartenza, int numeroOspiti){
    	  boolean isLibera = true;
    	  List<Camera> camerePossibili=cercaCamerePerNumeroOspiti(numeroOspiti);
    	  List<Camera> camereLibere= new ArrayList<>();
    	  for(Camera c: camerePossibili) {
    		  List<Prenotazione> prenotazioni= c.getPrenotazioni();
    		  for(Prenotazione p: prenotazioni) {
    			  Date arrivoPrenotata =p.getDataArrivo();
    			  Date partenzaPrenotata =p.getDataPartenza();
    			  if((dataArrivo.after(arrivoPrenotata) || dataArrivo.equals(arrivoPrenotata))&& dataArrivo.before(partenzaPrenotata)) {
    		  
    			  isLibera = false;
    	  }
    		  else
    		  
    			  
    		  
    			  if((dataPartenza.after(arrivoPrenotata) && dataPartenza.equals(partenzaPrenotata))|| dataPartenza.equals(partenzaPrenotata)) {
    		  
     			  isLibera = false;
    			  }
    		  }
    		  if (isLibera)
    		  	  camereLibere.add(c);
      
    	  }
    	  return camereLibere;
      }


   


	private List<Camera> cercaCamerePerNumeroOspiti(int numeroOspiti) {
		 List<Camera>  camere= findAll();
		 List<Camera> camerePerOspiti= new ArrayList<>();
		 for(Camera c: camere) {
			 if(c.getNumeroPosti() == numeroOspiti)
				 camerePerOspiti.add(c);
		
	}
		 return camerePerOspiti;
    	  
}



	public static Camera getCamera(Long id) {
		Optional<Camera> result = cameraRepository.findById(id);
		return result.orElse(null);
		
		
	}
}
