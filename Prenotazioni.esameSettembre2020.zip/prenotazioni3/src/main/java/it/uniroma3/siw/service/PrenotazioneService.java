package it.uniroma3.siw.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.uniroma3.siw.model.Prenotazione;
import it.uniroma3.siw.repository.PrenotazioneRepository;


@Service
public class PrenotazioneService {
	 @Autowired
	    protected PrenotazioneRepository prenotazioneRepository;

	 
	    @Transactional
	    public Prenotazione save(Prenotazione prenotazione) {
	        return this.prenotazioneRepository.save(prenotazione);
	    }


	
}